// Diagnostic input: make watchdog startup exceed the test's fixed 200 ms wait.
if (process.argv[2] === "watchdog") {
  await new Promise((resolve) => setTimeout(resolve, 600));
}
