# EN independent branch review — CHANGES_REQUESTED

- Reviewer: GPT-6 Astra, `@alari:16-m3.methodology.gpt-6-astra.sub-5`, case 1237.
- Base: `e515191a76fae4c7e239c40842cbbf3cb395962b`.
- Head: `680a0efc108f367b3ddb00a856db3703238adcd0`.
- Isolation: manual detached worktree `/Users/dmitry/code/verstak-ai/skills-review-1237-en`; session moved here. Candidate tracked files unchanged after corpus generation. No candidate fixes, merge, tag, release, new models or production graph probes.
- This is the light finished-branch review, not full frozen release acceptance. RU head was not supplied during this review and is not reviewed.

## Finding requiring a candidate correction

**F1 — P2: remove the obsolete handle requirement from the initial memory-guard projection.**

`skills/verstak/references/align-hooks.md:13` still instructs the onboarding initial-form caller to install “the memory guard with its graph and handle filled (`verstak_me(action="whoami")`)”. The new guard at line 55 deliberately has no handle slot. `skills/verstak/methods/onboarding.md:89` requires this initial form byte-for-byte; the stale instruction is on the actual bootstrap path, not historical prose. The candidate therefore changes the payload while leaving a caller requiring the removed identity input. On a handleless identity the new personal-memory entry can succeed, yet this next step still directs handle acquisition/filling, contrary to the no-handle contract.

Reproduce by reading line 13 and the JSON memory-guard command; `node dist/review-1237/probe-contract.mjs` asserts the stale instruction exists and the guard contains no `<handle>` slot. Fix the caller to fill only the remaining graph slot and route personal memory through minding; rebuild the bundle. No model behaviour is asserted from this textual counterexample.

## Additional inherited defect — separate disposition

**G1 — P2: the POSIX Claude memory guard accepts Windows-backslash memory paths.**

Locations: `skills/verstak/references/align-hooks.md:55`, `.claude/settings.json:9` (declared case-insensitive Windows coverage at reference line 50). These touched commands split/match only `/`; backslashes are not normalized.

Input, passed as JSON to the exact command through `/bin/sh`:

```json
{"tool_input":{"file_path":"C:\\Users\\review\\.claude\\projects\\review\\memory\\MEMORY.md"}}
```

Expected exit 2 and routing stderr; observed exit 0 and empty stderr, both reference projection and repository hook. Same input on immutable base also returns 0: **inherited, not introduced by this diff**. This is an input-shape probe on macOS/POSIX, not a native Windows harness observation. Do not report Windows guard acceptance. Its separate repair/exception is for the lead to decide; the EN change request above does not rely on treating it as a newly introduced release barrier.

## Personally executed

1. `bash scripts/build-skills.sh && make validate check-bundles check-surface && node --test js/tests/personal-entry.test.mjs js/tests/minding-contract.test.mjs` — exit 0; generated all four home outputs and bundle, byte-consistency checks pass; 36/36 text tests pass. `git status --short` remains empty. Log: `projections-and-text.log`.
2. `node dist/review-1237/probe-guards.mjs` — **exit 1**, 33/35 pass, two G1 failures. Raw structured results: `guard-results.json`; log: `guards.log`.
   - Exact Claude repo command and filled reference: POSIX absolute, relative, case-insensitive memory paths block with exit 2 and the new minding message; ordinary repo paths pass. Windows slash input blocks; backslash input fails to block.
   - Extracted OpenCode template, executed through setup/registered callbacks: write, edit, patch block all tested memory path forms and allow ordinary POSIX/Windows-shaped files; messages use minding and no handle locator. This witnesses callback behaviour, not loading by a live harness.
3. `node dist/review-1237/probe-contract.mjs` — exit 0 **for reproducing G1 on base and head and checking the other assertions**, not clearing the failing guard claim. Exact generated startup text emitted once for root and never for child in the fixture. Five merge controls: `fj pr merge` and a piped success fire; help, auto-merge and echo do not. No real merge or push executed. Logs: `contract.log`, `contract-results.json`.
4. `git diff --check <base> <head>` — exit 0.
5. Live read-only MCP `me(?)`, `realm(?)`, `me(readiness)`, `me(readiness, realm=r5)`. Actual readiness renders text, with artifact link and lacks, not an items JSON envelope. Current deployed API still reports personal_mind missing for assistant_karta; existing structural signs are present but ready=false without receipts; repository/agent_role nudges are dark rather than source_unavailable. These observations corroborate the still-open API mismatch #8205. No create/understood/update/delete probe ran.

## Read and reviewed

All changed source text, builder rewrites, generated onboarding, source minding and its full reference, template memory slot, hooks and delegation source branches; unchanged surrounding flow where needed. Generation proves home/minding's included appendix follows its source; its model effect is not tested. The new tests check phrase presence and synthetic deletion, not API/model behaviour.

The core entry correctly distinguishes verified personal ownership, absent realm versus missing role, unknown/refused reads, bare-slug foreign fallback, transient refs versus persistent locators, 409/uncertain create rereads, no organization owner, user-linked role in the correct realm, runtime persona versus progress, structural existence versus optional understanding receipt. Onboarding retains independent work on source_unavailable and prohibits duplicate provisioning and progress attrs. Existing role names/authorship and operational persona are preserved. Cleanup is provenance-based, not a graph sweep.

Author-only evidence, not rerun or adopted as my execution: case 1236 [8] reports `make build && make check` exit 0, 270/270, 23 prior warnings; [11]/[15] report PR214 and five CI checks passing. Full bridge gate was not repeated: no bridge-core/runtime delta here, targeted builder and guard checks cover the changed executable paths. No usage estimate is made.

## Integration and remaining acceptance obligations

- Read #7955/#8205, #7984/#7998/#7985/#8000/#8004, #2119/#1921/#1930/#4694, hint #8166; role #931 and holon #844; walked relevant method/principle consumers, #7955 next flow, UI nodes #4625/#4630/#7986.
- EN #844 and RU #1506, steward #931: text deliveries share the personal-memory method and contract wave. EN reviewed as above; RU immutable head/full gate **unknown to this review**. No RU approval.
- API #30, steward #48: readiness output #7953/#7955 feeds mind provisioning #2119 and selection #7999. #8205 remains **wake/open**: corrected API immutable head, multi-user isolation, attrs mutants, structural-no-receipt, identity-without-handle and integrated/deployed evidence must come from case1232. Current MCP is not that proof; foreign API repository was not read.
- MCP #31, steward #163: read-only text shape and accepted argument forms observed; no create conflict or handleless provisioning executed on production. Those runtime branches remain dependent on API evidence.
- UI: #4625/#4630 permanent companion still depends on handle; #7986 skill launch without chosen realm is separate. No UI repair imposed as a skills release condition, and no claim that skills remove the UI handle dependency.
- #8166 requires coordinated RU27→28 / EN4→5 release, both generated outputs and an observed full re-alignment from an old-stamped existing repository: memory slot/guard, start, `fj pr merge`, reviewer/verifier existing-seat branch. EN AGENTS remains honestly stamped 4. My extracted-template callback probes and source branch reading are **not** that re-alignment, nor evidence of live harness loading.
- Behaviour of an agent reading these skills and live application of newly projected rituals: **ceiling / not witnessed**. No paid model run or additional orchestration authorized or performed.
- F1 goes to the author; G1's separate fate and the above joint acceptance obligations stay with the lead. No graph modes or releases changed by this cold review.

## Carrier handoff

All files in this directory belong to this reviewer and contain no credentials. The worktree is retained only to hand over the report and executable/JSON/log carriers; no running test process, child agent or service remains. Copy/archive these carriers before removing this detached tree. It has no branch and no modified tracked candidate file.
