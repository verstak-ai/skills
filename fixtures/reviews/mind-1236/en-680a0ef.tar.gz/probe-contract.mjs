import assert from 'node:assert/strict';
import {readFileSync, writeFileSync} from 'node:fs';
import {execFileSync,spawnSync} from 'node:child_process';
import {resolve} from 'node:path';
const base='e515191a76fae4c7e239c40842cbbf3cb395962b';
const source=readFileSync('skills/verstak/references/align-hooks.md','utf8');
const old=execFileSync('git',['show',`${base}:skills/verstak/references/align-hooks.md`],{encoding:'utf8'});
const extract=t=>JSON.parse(t.split('## Memory guard')[1].match(/```json\n([\s\S]*?)\n```/)[1]).hooks[0].command;
const path=String.raw`C:\Users\review\.claude\projects\review\memory\MEMORY.md`;
const observations=[];
for (const [label,text] of [['base',old],['candidate',source]]) {
  const run=spawnSync('/bin/sh',['-c',extract(text)],{input:JSON.stringify({tool_input:{file_path:path}}),encoding:'utf8',env:{...process.env,HOME:resolve('dist/review-1237/nonexistent-home')}});
  observations.push({probe:'Windows-shaped input, POSIX runner',label,path,exit:run.status,stderr:run.stderr});
  assert.equal(run.status,0,`${label}: expected reproduction of observed bypass`);
}
observations.push({probe:'stale initial-form instruction',line:13,text:source.split('\n')[12],present:source.includes('memory guard with its graph and handle filled')});
assert.ok(source.includes('memory guard with its graph and handle filled'));
assert.ok(!extract(source).includes('<handle>'));
// Execute generated OpenCode callbacks; never call a real forge or run a model.
const {default:plugin}=await import('./projected-rituals.mjs');
const handlers={},prompts=[];
const root=process.cwd();
const stop=await plugin.setup({location:{directory:root},tool:{hook:async(k,f)=>handlers[k]=f},
 session:{get:async()=>({location:{directory:root}}),prompt:async p=>prompts.push(p)},
 event:{subscribe:async function*(){yield {type:'session.created',data:{sessionID:'review-root-contract',location:{directory:root}}};yield {type:'session.created',data:{sessionID:'review-child-contract',parentID:'review-root-contract',location:{directory:root}}};}},
});
for(let i=0;i<20;i++) await new Promise(r=>setImmediate(r));
assert.equal(prompts.length,1);
assert.equal(prompts[0].text,'Load the verstak skill first (/verstak) and read its Start section before any other action. Addresses from AGENTS.md: graph @nks/nks-dev, focus holon #844, agent role #931, owner role #1226.');
observations.push({probe:'start callback root once, child skipped',result:prompts});
for(const [id,command,output,expected] of [
 ['merge','fj pr merge 42','',true],
 ['merge-pipe','fj pr merge 42 | tail','Merged PR #42',true],
 ['merge-help','fj pr merge --help','',false],
 ['merge-auto','gh pr merge 42 --auto','',false],
 ['merge-echo','echo "fj pr merge 42"','',false],
]) {
 const input={id:`review-${id}`,sessionID:'review',tool:'shell',status:'completed',input:{command},result:{content:output,metadata:{exit:0}}};
 await handlers['execute.after'](input);
 const fired=input.result.content.includes('[verstak] Merged:');
 assert.equal(fired,expected,command);
 observations.push({probe:'merge callback',command,output,expected,fired});
}
stop();
const delegation=readFileSync('skills/verstak/references/align-delegation.md','utf8');
for(const role of ['verifier','reviewer']) {
 const block=delegation.split('name: '+role+'\n')[1].split('```')[0];
 assert.match(block,/If the harness already ran the line, you are seated and joined; otherwise/);
 observations.push({probe:'delegation source branch (text only)',role,alreadySeatedIsKept:true});
}
writeFileSync('dist/review-1237/contract-results.json',JSON.stringify(observations,null,2)+'\n');
console.log('Reproduced inherited Windows-path gap on base and candidate; stale handle instruction remains.');
console.log('PASS generated start: exact text, root once/child skip; merge: 5 controls; verifier/reviewer branch: text only.');
console.log('This exit0 confirms those observations, not a Windows-guard acceptance or a live realignment.');
