import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {spawnSync,execFileSync} from 'node:child_process';
import {dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
const scratch=dirname(fileURLToPath(import.meta.url));
const out=join(scratch,'results');
const results=[];
function run(label,args,expected=0,env={}) {
  const r=spawnSync(args[0],args.slice(1),{encoding:'utf8',env:{...process.env,VERSTAK_BRIDGE_NO_BROWSER:'1',...env},maxBuffer:20*1024*1024});
  writeFileSync(join(out,label+'.log'),(r.stdout||'')+(r.stderr||''));
  results.push({label,args,expected,exit:r.status,error:r.error?.message});
  writeFileSync(join(out,'commands.json'),JSON.stringify(results,null,2)+'\n');
  console.log(label,r.status);
  assert.equal(r.status,expected,`${label}: ${r.stderr}`);
}
for (const name of ['probe-guards.mjs','probe-contract.mjs']) {
  const source=readFileSync(join(scratch,'original',name),'utf8');
  // Only carrier-output locations change; all original assertions remain intact.
  writeFileSync(join(out,name),source.replaceAll('dist/review-1237',out));
}
run('original-guards',['node',join(out,'probe-guards.mjs')]);
// Original defect detector must now refuse the fixed head (expects bypass exit0).
run('original-defect-detector',['node',join(out,'probe-contract.mjs')],1);
let fixed=readFileSync(join(out,'probe-contract.mjs'),'utf8')
  .replace("assert.equal(run.status,0,`${label}: expected reproduction of observed bypass`);","assert.equal(run.status,label==='base'?0:2,`${label}: exact original input`);")
  .replace("assert.ok(source.includes('memory guard with its graph and handle filled'));","assert.ok(!source.includes('memory guard with its graph and handle filled'));\nassert.match(source,/memory guard with its project graph filled/);")
  .replace('Reproduced inherited Windows-path gap on base and candidate; stale handle instruction remains.','Base bypass reproduced; candidate blocks exact G1 input; stale F1 caller absent.')
  .replace('This exit0 confirms those observations, not a Windows-guard acceptance or a live realignment.','POSIX command/callback observations only; no native Windows or live realignment.');
writeFileSync(join(out,'probe-contract-fixed.mjs'),fixed);
run('fixed-contract',['node',join(out,'probe-contract-fixed.mjs')]);
run('current-memory-paths',['node','--test','js/tests/memory-paths.test.mjs']);
for (const [label,rev] of [['previous','680a0efc108f367b3ddb00a856db3703238adcd0'],['base','e515191a76fae4c7e239c40842cbbf3cb395962b']]) {
  const root=join(scratch,label);
  for(const path of ['skills/verstak/references/align-hooks.md','.claude/settings.json']) {
    mkdirSync(dirname(join(root,path)),{recursive:true});
    writeFileSync(join(root,path),execFileSync('git',['show',`${rev}:${path}`]));
  }
  run(label+'-negative-control',['node','--test','js/tests/memory-paths.test.mjs'],1,{MEMORY_GUARD_ROOT:root});
}
run('text-contract',['node','--test','js/tests/personal-entry.test.mjs','js/tests/minding-contract.test.mjs']);
run('diff-check',['git','diff','--check','e515191a76fae4c7e239c40842cbbf3cb395962b','cfb00e113af6b01f84fa0cc0ad3f340d15b78d7f']);
