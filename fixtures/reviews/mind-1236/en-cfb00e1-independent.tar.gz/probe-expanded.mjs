import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync,symlinkSync,rmSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
const scratch=dirname(fileURLToPath(import.meta.url)), root=process.cwd();
const area=join(scratch,'path-fixtures');
mkdirSync(join(area,'ordinary/sub'),{recursive:true});
symlinkSync('/nonexistent/.claude/projects/review/memory',join(area,'alias'));
symlinkSync(join(area,'ordinary/sub'),join(area,'safe-alias'));
symlinkSync('loop-b',join(area,'loop-a'));
symlinkSync('loop-a',join(area,'loop-b'));
const text=readFileSync('skills/verstak/references/align-hooks.md','utf8');
const reference=JSON.parse(text.split('## Memory guard')[1].match(/```json\n([\s\S]*?)\n```/)[1]).hooks[0].command;
const settings=JSON.parse(readFileSync('.claude/settings.json','utf8'));
const command=settings.hooks.PreToolUse.flatMap(x=>x.hooks)[0].command;
assert.equal(reference.replaceAll('<@owner/slug>','@nks/nks-dev'),command);
const cases=[
 ['posix-traversal','/nonexistent/.claude/projects/review/other/../memory/n.md',true],
 ['posix-dot','/nonexistent/.claude//projects/review/./memory/n.md',true],
 ['memory-directory','/nonexistent/.claude/projects/review/memory',true],
 ['relative-traversal','.claude/projects/review/other/../memory/n.md',true],
 ['win-drive',String.raw`C:\Users\review\.claude\projects\review\memory\MEMORY.md`,true],
 ['win-case',String.raw`C:\Users\review\.CLAUDE\Projects\review\MeMoRy\note.md`,true],
 ['win-traversal',String.raw`C:\Users\review\.claude\projects\review\other\..\memory\note.md`,true],
 ['unc',String.raw`\\server\users\review\.claude\projects\review\memory\note.md`,true],
 ['unc-traversal',String.raw`\\server\users\review\.claude\projects\review\other\..\memory\note.md`,true],
 ['mixed-separators',String.raw`C:\Users/review\.claude/projects\review/other\../memory\note.md`,true],
 ['symlink-memory',join(area,'alias/n.md'),true],
 ['symlink-loop',join(area,'loop-a/n.md'),true],
 ['safe-symlink',join(area,'safe-alias/n.md'),false],
 ['safe-symlink-parent',join(area,'safe-alias/../n.md'),false],
 ['ordinary-posix','docs/ordinary.md',false],
 ['ordinary-parent','docs/sub/../ordinary.md',false],
 ['ordinary-memory','memory/ordinary.md',false],
 ['ordinary-memory-sibling','.claude/projects/review/memory-cache/n.md',false],
 ['ordinary-windows',String.raw`C:\work\repo\docs\ordinary.md`,false],
 ['ordinary-windows-parent',String.raw`C:\work\repo\docs\sub\..\ordinary.md`,false],
 ['ordinary-unc',String.raw`\\server\work\repo\memory\ordinary.md`,false],
 ['ordinary-dotclaude',String.raw`C:\work\.claude\settings.json`,false],
 ['empty','',false],
];
const {default:plugin}=await import('./results/projected-rituals.mjs');
const handlers={};
const stop=await plugin.setup({location:{directory:root},session:{get:async()=>({location:{directory:root}})},tool:{hook:async(k,fn)=>handlers[k]=fn},event:{subscribe:async function*(){}}});
const rows=[];
try {
 for(const [name,path,blocked] of cases) {
  for(const [carrier,cmd] of [['reference',reference],['repository',command]]) {
   for(const field of ['file_path','notebook_path']) {
    const r=spawnSync('/bin/sh',['-c',cmd],{cwd:root,input:JSON.stringify({tool_input:{[field]:path}}),encoding:'utf8',env:{...process.env,HOME:join(area,'nonexistent-home')}});
    rows.push({carrier,field,name,path,expected:blocked?2:0,exit:r.status,stderr:r.stderr,pass:r.status===(blocked?2:0)&&(blocked?/minding/.test(r.stderr):r.stderr==='')});
   }
  }
  for(const tool of ['write','edit','patch']) {
   if(!path && tool==='patch') continue;
   let error=null;
   try {await handlers['execute.before']({sessionID:'expanded',tool,input:tool==='patch'?{patchText:`*** Begin Patch\n*** Add File: ${path}\n+x\n*** End Patch`}:{path}});} catch(e){error=e.message;}
   rows.push({carrier:'opencode',tool,name,path,blocked,error,pass:!!error===blocked&&(!error||/minding/.test(error))});
  }
 }
 // PATCH destinations are part of the public guard boundary too.
 for(const header of ['Update File','Delete File','Move to']) {
  let error=null;
  try {await handlers['execute.before']({sessionID:'expanded',tool:'patch',input:{patchText:`*** Begin Patch\n*** ${header}: ${cases[4][1]}\n*** End Patch`}});}catch(e){error=e.message;}
  rows.push({carrier:'opencode',header,error,pass:!!error});
 }
 for(const [carrier,cmd] of [['reference',reference],['repository',command]]) {
  for(const input of [{},{tool_input:{}},{tool_input:{notebook_path:null}}]) {
   const r=spawnSync('/bin/sh',['-c',cmd],{input:JSON.stringify(input),encoding:'utf8'});
   rows.push({carrier,input,exit:r.status,pass:r.status===0&&r.stderr===''});
  }
 }
} finally {stop();rmSync(area,{recursive:true,force:true});}
writeFileSync(join(scratch,'results/expanded-results.json'),JSON.stringify(rows,null,2)+'\n');
for(const row of rows.filter(x=>!x.pass)) console.log('FAIL',row);
console.log(`${rows.filter(x=>x.pass).length}/${rows.length} passed; no memory writes; commands/callbacks only`);
assert.ok(rows.every(x=>x.pass));
