import assert from 'node:assert/strict';
import {readFileSync, writeFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {resolve} from 'node:path';

// Runs guard commands/callbacks only: no attempted write to any memory directory.
const root = process.cwd();
const hooksText = readFileSync('skills/verstak/references/align-hooks.md', 'utf8');
const guardJSON = hooksText.split('## Memory guard')[1].match(/```json\n([\s\S]*?)\n```/)[1];
const projected = JSON.parse(guardJSON).hooks[0].command.replaceAll('<@owner/slug>', '@nks/nks-dev');
const actual = JSON.parse(readFileSync('.claude/settings.json', 'utf8')).hooks.PreToolUse
  .flatMap(x => x.hooks).find(x => x.command.includes('local agent memory')).command;
assert.equal(actual, projected, 'repo guard equals filled reference');
const hookSource = readFileSync('skills/verstak/references/align-harness-surfaces.md', 'utf8')
  .match(/```js\n([\s\S]*?)\n```/)[1]
  .replaceAll('<@owner/slug>', '@nks/nks-dev')
  .replaceAll('<Graph>', '@nks/nks-dev')
  .replaceAll('<Focus holon>', '844').replaceAll('<Agent role>', '931').replaceAll('<Owner role>', '1226');
writeFileSync('/private/var/folders/hm/186b3lk15fxb215c3ypxgmv00000gn/T/opencode/review-1238/results/projected-rituals.mjs', hookSource);
const {default: plugin} = await import('./projected-rituals.mjs');
const callbacks = {};
const stop = await plugin.setup({
  location: {directory: root},
  session: {get: async () => ({location: {directory: root}})},
  tool: {hook: async (name, fn) => {callbacks[name] = fn;}},
  event: {subscribe: async function* () {}},
});
const cases = [
  ['unix-memory', '/nonexistent/.claude/projects/review/memory/MEMORY.md', true],
  ['relative-memory', '.claude/projects/review/memory/note.md', true],
  ['mixed-case', '/nonexistent/.CLAUDE/Projects/review/MeMoRy/note.md', true],
  ['windows-backslash', String.raw`C:\Users\review\.claude\projects\review\memory\MEMORY.md`, true],
  ['windows-slash', 'C:/Users/review/.claude/projects/review/memory/MEMORY.md', true],
  ['ordinary-file', 'docs/ordinary.md', false],
  ['ordinary-windows', String.raw`C:\work\repo\docs\ordinary.md`, false],
];
const results = [];
for (const [name, path, expectedBlock] of cases) {
  for (const [surface, command] of [['claude-projection', projected], ['claude-repo', actual]]) {
    const run = spawnSync('/bin/sh', ['-c', command], {
      cwd: root, input: JSON.stringify({tool_input:{file_path:path}}), encoding:'utf8',
      env: {...process.env, HOME:resolve('/private/var/folders/hm/186b3lk15fxb215c3ypxgmv00000gn/T/opencode/review-1238/results/nonexistent-home')},
    });
    const messageOK = !expectedBlock || (/personal mind through the minding method/.test(run.stderr) && !/@<?handle>?\/mind/.test(run.stderr));
    results.push({surface,name,input:path,expectedExit:expectedBlock?2:0,exit:run.status,stderr:run.stderr,pass:run.status===(expectedBlock?2:0)&&messageOK});
  }
  for (const tool of ['write','edit','patch']) {
    let error;
    try {await callbacks['execute.before']({sessionID:'review',tool,input:tool==='patch'?{patchText:`*** Begin Patch\n*** Add File: ${path}\n+x\n*** End Patch`}:{path}});} catch(e) {error=e.message;}
    results.push({surface:`opencode-projection-${tool}`,name,input:path,expectedBlock,error:error??null,pass:!!error===expectedBlock&&(!error||(/personal mind through the minding method/.test(error)&&!/@<?handle>?\/mind/.test(error)))});
  }
}
stop();
writeFileSync('/private/var/folders/hm/186b3lk15fxb215c3ypxgmv00000gn/T/opencode/review-1238/results/guard-results.json',JSON.stringify({platform:process.platform,root,results},null,2)+'\n');
for (const r of results) console.log(`${r.pass?'PASS':'FAIL'} ${r.surface} ${r.name} ${r.exit??(r.error?'blocked':'allowed')}`);
console.log(`${results.filter(r=>r.pass).length}/${results.length} passed; POSIX runner; Windows paths are input probes, not a native Windows harness run.`);
process.exitCode=results.some(r=>!r.pass)?1:0;
