# EN independent recheck — APPROVE

Reviewer: GPT-6 Astra, new session `ses_ea6a66e45ffeIC1T21ovcIgaEb`, own satellite
`@alari:16-m3.methodology.gpt-6-astra.sub-5`, case 1238.

- Exact candidate: `cfb00e113af6b01f84fa0cc0ad3f340d15b78d7f`.
- Previous rejected head: `680a0efc108f367b3ddb00a856db3703238adcd0`.
- Original base: `e515191a76fae4c7e239c40842cbbf3cb395962b`.
- Manual isolation: detached `/Users/dmitry/code/verstak-ai/skills-review-1238`.
- This is the light finished-branch recheck, not release acceptance. No candidate
  product edit, commit, merge or tag; no nested agents, paid models or Rust/PG gate.

## Findings

**F1 P2: resolved.** `skills/verstak/references/align-hooks.md:13` now asks only
for the project graph and explicitly routes the personal branch through minding
without a handle or stored address. Its caller,
`skills/verstak/methods/onboarding.md:89`, still requires the exact initial form;
that form now agrees with the guard. The filled source command equals
`.claude/settings.json:9`. Source/bundle regeneration is byte-consistent.

**G1 P2: resolved within the accepted POSIX-runner input contract.** The exact
original `C:\Users\review\.claude\projects\review\memory\MEMORY.md` input now
exits 2 on both Claude commands, with the minding route in stderr. The jq step
normalizes backslashes before the existing resolution and memory checks.
The same input on the original base exits 0. The current regression test rejects
both the previous head and original base: 16 failing cases, exit 1, each.

**New findings: none in the reviewed scope.** Expanded allowed-path controls,
parent traversal, links and loops did not expose a regression. This does not
claim correctness for every possible path or a native Windows harness.

## Personally executed evidence

All logs and structured results are in `results/`. The first two commands ran
from the detached candidate root, with no product changes between them and the
probes. `git status --short` after generation and testing was empty.

| Command / carrier | Observed result |
|---|---|
| `make build` | exit 0; fresh dev outputs, source bundle and all four home outputs |
| `VERSTAK_BRIDGE_NO_BROWSER=1 make check` | exit 0; 306 tests, 306 pass, 0 fail; lint reports 23 warnings, 0 errors |
| `node <evidence>/run-review.mjs` | exit 0; every expected command exit asserted, recorded in `results/commands.json` |
| Original `probe-guards.mjs`, only output paths redirected | exit 0, 35/35; exact Claude commands and generated OpenCode write/edit/patch callbacks |
| Original `probe-contract.mjs`, only output paths redirected | expected exit 1 on the repaired candidate: its assertion expecting the old bypass exit 0 is now false |
| `probe-contract-fixed.mjs` | exit 0; identical G1 input is allowed on base and blocked on head; F1 stale caller absent; original start/merge/delegation checks pass |
| `node --test js/tests/memory-paths.test.mjs` | exit 0, 36/36 |
| Same test, `MEMORY_GUARD_ROOT=<previous-carriers>` | expected exit 1, 20 pass / 16 fail; exact files from `680a0ef` via `git show` |
| Same test, `MEMORY_GUARD_ROOT=<base-carriers>` | expected exit 1, 20 pass / 16 fail; exact files from `e515191` via `git show` |
| `node --test js/tests/personal-entry.test.mjs js/tests/minding-contract.test.mjs` | exit 0, 36/36; text presence, not model/API behaviour |
| `node <evidence>/probe-expanded.mjs` | exit 0, 169/169 command/callback observations; no memory file writes |
| `git diff --check e515191a76fae4c7e239c40842cbbf3cb395962b cfb00e113af6b01f84fa0cc0ad3f340d15b78d7f` | exit 0 |

Expanded probes cover both Claude path fields (`file_path`, `notebook_path`),
POSIX absolute and relative paths, case, repeated separators/dot, Windows drive,
UNC, mixed separators, parent traversal, a symlink to a nonexistent memory path,
a symlink loop, allowed ordinary files, allowed links and parent traversal,
ordinary memory-named directories and memory-cache siblings, empty/missing/null
inputs. OpenCode write/edit/patch callbacks see the same paths; patch Update,
Delete and Move headers also block the Windows memory destination. Callbacks are
extracted afresh from the candidate's reference, not copied from the old result.

Original contract callback checks preserved: exact startup text, root once and
child skipped; `fj pr merge` and piped success fire, help/auto/echo do not;
verifier/reviewer already-seated branches remain present (text observation).
The corrective delta does not change start/merge, delegation, OpenCode source,
home generation or the home outputs. Repository start/merge entries remain
unchanged; the previously stated old-projection ceiling is not lifted.

## Grounding, projection and integration scope

Read `AGENTS.md`, `REALITY.md`, the source door, reality-audit/code-work/reconcile;
nodes #7998, #7984, #7955, #8205, #8166; role #931, holon #844 and the #7998 trace.
Read case1237 [10–12] and case1236 [29]. The graph holds the system and its method
delivery; the source corpus remains the EN product carrier.

Read the complete `680a0ef..cfb00e1` nonbinary delta, the current callers and
surroundings: minding/onboarding, personal-memory entry reference, initial guard,
OpenCode projection, settings, template, align, foreman and home builder changes.
The sources preserve owner-bound current identity; current API artifact link,
not a constructed address; user binding in the chosen realm; missing versus
unknown/refused; structural existence without receipts/attrs; separate runtime
companion persona. The reference explicitly calls MCP readiness text, not an
assumed JSON envelope. Build/check regenerated matching home and bundle outputs.

No graph content or modes changed by this read-only review. The case carries the
per-head acceptance. #7998/#7984 describe the intended method consistently with
the examined EN text; #8205 and #8166 remain open with their existing carriers.
No new requirement or release barrier was introduced.

## Explicit ceilings

- No RU review or approval, coordinated RU28/EN5 release, or product publication.
- No repaired API `1d972558` gate, integrated multi-user ownership/readiness,
  mutation/isolation test or deployed API acceptance; API work stays separate.
- No live complete re-alignment of an existing repo; its stamp remains 4,
  deliberately unchanged for immutable review. Contract 5 is not evidence that
  old repository projections were replaced (#8166).
- No native Windows harness, live loading of changed hooks, model behaviour or
  paid model run. Shell commands and generated callbacks were exercised directly.
- UI companion handle prerequisites remain separate, not a skills release gate.
- Full EN check uses the suite's local fake transport; it does not witness a real
  identity-provider crossing. No production write or personal mind content read.

## Evidence provenance and handoff

`fixtures/reviews/mind-1236/en-680a0ef.tar.gz` was listed before extraction. All
nine regular members were copied into `original/`; the input archive SHA256 was
checked as `b8049d7937a73c20cef6170a2e44041214263ad7f5e459d1b85abc318fb3982a`.
The original files and archive were never edited. New results are separate.
`run-review.mjs` documents all adaptations: only output locations in the original
guard and defect detector; the fixed contract copy changes the now-inverted
defect assertions and its summary, retaining startup/merge/role checks.

The archive of this review is handed to the lead/author for tracked persistence
before scratch/worktree removal. This report and executable probes are not left
as an ignored dist-only copy. Test commands completed; synthetic link fixtures
were removed by the expanded probe's finally block. No shared process was stopped.
